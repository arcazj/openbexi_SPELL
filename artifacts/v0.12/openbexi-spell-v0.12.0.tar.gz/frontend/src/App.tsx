import { AlertCircle, Database, ServerCog, Workflow, X } from "lucide-react";
import { useEffect, useState } from "react";
import { AUTH_CHANGED_EVENT, getAccessToken } from "./api";
import { AccessTokenGate } from "./components/AccessTokenGate";
import { ConsoleHeader } from "./components/ConsoleHeader";
import { DataDock } from "./components/DataDock";
import { DataServiceWorkspace } from "./components/DataServiceWorkspace";
import { DriverProjection } from "./components/DriverProjection";
import { ExecutionWorkspace } from "./components/ExecutionWorkspace";
import { InstanceMaster } from "./components/InstanceMaster";
import { ProcedureCatalog } from "./components/ProcedureCatalog";
import { useAppDispatch, useAppSelector } from "./hooks";
import { bootstrap, dismissError } from "./store";
import { useExecutionStream } from "./useExecutionStream";

export default function App() {
  const dispatch = useAppDispatch();
  const error = useAppSelector((state) => state.console.error);
  const [accessToken, setCurrentAccessToken] = useState(() => getAccessToken());
  const [activeView, setActiveView] = useState<"execution" | "driver" | "data">("execution");
  const authenticated = Boolean(accessToken);
  useExecutionStream(accessToken);

  useEffect(() => {
    const updateAuthentication = () => setCurrentAccessToken(getAccessToken());
    window.addEventListener(AUTH_CHANGED_EVENT, updateAuthentication);
    return () => window.removeEventListener(AUTH_CHANGED_EVENT, updateAuthentication);
  }, []);

  useEffect(() => {
    if (accessToken) void dispatch(bootstrap());
  }, [accessToken, dispatch]);

  if (!authenticated) return <AccessTokenGate />;

  return (
    <div className="app-frame">
      <ConsoleHeader />
      <div className="status-area">
        {error && (
          <div className="error-banner" role="alert">
            <AlertCircle aria-hidden="true" size={17} />
            <span>{error}</span>
            <button
              type="button"
              aria-label="Dismiss error"
              title="Dismiss error"
              onClick={() => dispatch(dismissError())}
            >
              <X aria-hidden="true" size={16} />
            </button>
          </div>
        )}
        <div className="workspace-tabs" role="tablist" aria-label="Console views">
          <button
            id="workspace-tab-execution"
            type="button"
            role="tab"
            aria-selected={activeView === "execution"}
            aria-controls="workspace-panel-execution"
            tabIndex={activeView === "execution" ? 0 : -1}
            onClick={() => setActiveView("execution")}
            onKeyDown={(event) => {
              if (event.key === "ArrowRight") {
                event.preventDefault();
                setActiveView("driver");
                document.getElementById("workspace-tab-driver")?.focus();
              } else if (event.key === "End") {
                event.preventDefault();
                setActiveView("data");
                document.getElementById("workspace-tab-data")?.focus();
              }
            }}
          >
            <Workflow aria-hidden="true" size={15} />
            <span>Execution</span>
          </button>
          <button
            id="workspace-tab-driver"
            type="button"
            role="tab"
            aria-selected={activeView === "driver"}
            aria-controls="workspace-panel-driver"
            tabIndex={activeView === "driver" ? 0 : -1}
            onClick={() => setActiveView("driver")}
            onKeyDown={(event) => {
              if (event.key === "ArrowLeft" || event.key === "Home") {
                event.preventDefault();
                setActiveView("execution");
                document.getElementById("workspace-tab-execution")?.focus();
              } else if (event.key === "ArrowRight" || event.key === "End") {
                event.preventDefault();
                setActiveView("data");
                document.getElementById("workspace-tab-data")?.focus();
              }
            }}
          >
            <ServerCog aria-hidden="true" size={15} />
            <span>Driver foundation</span>
          </button>
          <button
            id="workspace-tab-data"
            type="button"
            role="tab"
            aria-selected={activeView === "data"}
            aria-controls="workspace-panel-data"
            tabIndex={activeView === "data" ? 0 : -1}
            onClick={() => setActiveView("data")}
            onKeyDown={(event) => {
              if (event.key === "ArrowLeft") {
                event.preventDefault();
                setActiveView("driver");
                document.getElementById("workspace-tab-driver")?.focus();
              } else if (event.key === "ArrowRight" || event.key === "Home") {
                event.preventDefault();
                setActiveView("execution");
                document.getElementById("workspace-tab-execution")?.focus();
              }
            }}
          >
            <Database aria-hidden="true" size={15} />
            <span>Data services</span>
          </button>
        </div>
      </div>
      {activeView === "execution" ? (
        <div
          id="workspace-panel-execution"
          className="console-layout"
          role="tabpanel"
          aria-labelledby="workspace-tab-execution"
        >
          <ProcedureCatalog />
          <div className="work-region">
            <InstanceMaster />
            <ExecutionWorkspace />
            <DataDock />
          </div>
        </div>
      ) : activeView === "driver" ? (
        <div
          id="workspace-panel-driver"
          className="driver-shell"
          role="tabpanel"
          aria-labelledby="workspace-tab-driver"
        >
          <DriverProjection />
        </div>
      ) : (
        <div
          id="workspace-panel-data"
          className="data-shell"
          role="tabpanel"
          aria-labelledby="workspace-tab-data"
        >
          <DataServiceWorkspace />
        </div>
      )}
    </div>
  );
}
