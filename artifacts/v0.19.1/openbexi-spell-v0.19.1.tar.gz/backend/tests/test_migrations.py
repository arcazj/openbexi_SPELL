from __future__ import annotations

import json
import multiprocessing
import os
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

import pytest
from sqlalchemy import (
    CheckConstraint,
    Index,
    MetaData,
    Table,
    UniqueConstraint,
    create_engine,
    inspect,
    text,
)
from sqlalchemy.engine import make_url

import backend.migrations as migration_runner
from backend.database import Base
from backend.migrations import database_version, schema_migrations
from backend.migrations.versions import (
    v0001_initial,
    v0002_execution_variables,
    v0003_driver_foundation,
    v0004_operator_workspace,
    v0005_observation_projection,
    v0006_observation_conditions,
    v0007_data_local_service,
    v0011_dss_language_ledger,
)
from backend.tests.migration_support import reset_test_database, run_migrations


DRIVER_TABLES = tuple(
    table.name for table in v0003_driver_foundation.metadata.sorted_tables
)
OPERATOR_TABLES = tuple(
    table.name for table in v0004_operator_workspace.NEW_TABLES
)
OBSERVATION_TABLES = tuple(
    table.name for table in v0005_observation_projection.NEW_TABLES
)
CONDITION_TABLES = tuple(
    table.name for table in v0006_observation_conditions.NEW_TABLES
)
DATA_TABLES = tuple(table.name for table in v0007_data_local_service.NEW_TABLES)
V03_TABLES = ("executions", "events", "commands", "prompts")
V0007_CRASH_EXIT_CODE = 87


def crash_after_first_v0007_sqlite_ddl(
    database_path: str, backup_directory: str
) -> None:
    original_create = Table.create

    def create_then_crash(table, bind, *args, **kwargs):
        result = original_create(table, bind, *args, **kwargs)
        if table.name == DATA_TABLES[0]:
            os._exit(V0007_CRASH_EXIT_CODE)
        return result

    Table.create = create_then_crash
    engine = create_engine(f"sqlite:///{Path(database_path).as_posix()}")
    migration_runner.run_migrations(
        engine,
        v0007_backup_directory=Path(backup_directory),
    )


def reset_migration_database(engine) -> None:
    reset_test_database(engine)


def assert_driver_schema_contract(engine) -> None:
    """Prove the static migration reflects the same contract on each dialect."""

    inspector = inspect(engine)
    actual_tables = set(inspector.get_table_names())
    assert set(DRIVER_TABLES) <= actual_tables
    for expected in v0003_driver_foundation.metadata.sorted_tables:
        table_name = expected.name
        actual_columns = {item["name"]: item for item in inspector.get_columns(table_name)}
        assert set(actual_columns) == set(expected.columns.keys())
        assert {
            name for name, column in actual_columns.items() if not column["nullable"]
        } == {
            column.name for column in expected.columns if not column.nullable
        }
        assert set(inspector.get_pk_constraint(table_name)["constrained_columns"]) == {
            column.name for column in expected.primary_key.columns
        }

        expected_unique = {
            tuple(column.name for column in constraint.columns)
            for constraint in expected.constraints
            if isinstance(constraint, UniqueConstraint)
        }
        actual_unique = {
            tuple(constraint["column_names"])
            for constraint in inspector.get_unique_constraints(table_name)
        }
        assert expected_unique <= actual_unique
        expected_named_unique = {
            constraint.name
            for constraint in expected.constraints
            if isinstance(constraint, UniqueConstraint) and constraint.name is not None
        }
        actual_named_unique = {
            constraint["name"]
            for constraint in inspector.get_unique_constraints(table_name)
        }
        assert expected_named_unique <= actual_named_unique

        expected_checks = {
            constraint.name
            for constraint in expected.constraints
            if isinstance(constraint, CheckConstraint)
        }
        actual_checks = {
            constraint["name"]
            for constraint in inspector.get_check_constraints(table_name)
        }
        assert expected_checks <= actual_checks

        expected_foreign_keys = {
            (
                tuple(column.name for column in constraint.columns),
                constraint.referred_table.name,
                tuple(element.column.name for element in constraint.elements),
            )
            for constraint in expected.foreign_key_constraints
        }
        actual_foreign_keys = {
            (
                tuple(constraint["constrained_columns"]),
                constraint["referred_table"],
                tuple(constraint["referred_columns"]),
            )
            for constraint in inspector.get_foreign_keys(table_name)
        }
        assert expected_foreign_keys == actual_foreign_keys

        expected_indexes = {
            (index.name, tuple(column.name for column in index.columns))
            for index in expected.indexes
            if isinstance(index, Index)
        }
        actual_indexes = {
            (index["name"], tuple(index["column_names"]))
            for index in inspector.get_indexes(table_name)
            if not index.get("duplicates_constraint")
        }
        assert expected_indexes <= actual_indexes

    with engine.connect() as connection:
        profile = connection.execute(
            text(
                "SELECT id, server_profile_id, logical_driver_id, simulator, enabled, "
                "contract_package, configuration_schema_version, configuration_digest, "
                "credential_reference, credential_epoch, max_contexts_per_host, "
                "max_attachments_per_context, max_lifecycle_operations_per_host, "
                "max_lifecycle_operations_per_context, journal_max_entries, "
                "journal_max_bytes, revision FROM driver_profiles"
            )
        ).mappings().one()
    assert dict(profile) == {
        "id": "local-synthetic-simulator",
        "server_profile_id": "local-synthetic",
        "logical_driver_id": "bundled-deterministic-simulator",
        "simulator": True,
        "enabled": False,
        "contract_package": "spell.driver.v1",
        "configuration_schema_version": "spell.driver.host-profile/1",
        "configuration_digest": (
            "5eb17949cc4a33a460937e96d6ecc3c76ba190497d6adeb0cd673d4adfeef198"
        ),
        "credential_reference": "local-v04-driver-mtls",
        "credential_epoch": 1,
        "max_contexts_per_host": 1,
        "max_attachments_per_context": 1,
        "max_lifecycle_operations_per_host": 8,
        "max_lifecycle_operations_per_context": 8,
        "journal_max_entries": 10_000,
        "journal_max_bytes": 16_777_216,
        "revision": 0,
    }


def assert_operator_schema_contract(engine) -> None:
    inspector = inspect(engine)
    actual_tables = set(inspector.get_table_names())
    assert set(OPERATOR_TABLES) <= actual_tables
    for expected in v0004_operator_workspace.NEW_TABLES:
        table_name = expected.name
        actual_columns = {item["name"]: item for item in inspector.get_columns(table_name)}
        assert set(actual_columns) == set(expected.columns.keys())
        assert {
            name for name, column in actual_columns.items() if not column["nullable"]
        } == {
            column.name for column in expected.columns if not column.nullable
        }
        assert set(inspector.get_pk_constraint(table_name)["constrained_columns"]) == {
            column.name for column in expected.primary_key.columns
        }
        expected_foreign_keys = {
            (
                tuple(column.name for column in constraint.columns),
                constraint.referred_table.name,
                tuple(element.column.name for element in constraint.elements),
            )
            for constraint in expected.foreign_key_constraints
        }
        actual_foreign_keys = {
            (
                tuple(constraint["constrained_columns"]),
                constraint["referred_table"],
                tuple(constraint["referred_columns"]),
            )
            for constraint in inspector.get_foreign_keys(table_name)
        }
        assert expected_foreign_keys == actual_foreign_keys
        expected_checks = {
            constraint.name
            for constraint in expected.constraints
            if isinstance(constraint, CheckConstraint)
        }
        actual_checks = {
            constraint["name"]
            for constraint in inspector.get_check_constraints(table_name)
        }
        assert expected_checks <= actual_checks
    with engine.connect() as connection:
        context = connection.execute(
            text(
                "SELECT id, name, settings, revision "
                "FROM operator_contexts WHERE id='simulator'"
            )
        ).mappings().one()
    assert context["id"] == "simulator"
    assert context["name"] == "Local Synthetic Simulator"
    assert context["revision"] == 0


def assert_observation_schema_contract(engine) -> None:
    inspector = inspect(engine)
    assert set(OBSERVATION_TABLES) <= set(inspector.get_table_names())
    for expected in v0005_observation_projection.NEW_TABLES:
        actual_columns = {
            item["name"]: item
            for item in inspector.get_columns(expected.name)
        }
        assert set(actual_columns) == set(expected.columns.keys())
        assert {
            name for name, column in actual_columns.items() if not column["nullable"]
        } == {
            column.name for column in expected.columns if not column.nullable
        }
        assert set(inspector.get_pk_constraint(expected.name)["constrained_columns"]) == {
            column.name for column in expected.primary_key.columns
        }
        expected_foreign_keys = {
            (
                tuple(column.name for column in constraint.columns),
                constraint.referred_table.name,
                tuple(element.column.name for element in constraint.elements),
            )
            for constraint in expected.foreign_key_constraints
        }
        actual_foreign_keys = {
            (
                tuple(constraint["constrained_columns"]),
                constraint["referred_table"],
                tuple(constraint["referred_columns"]),
            )
            for constraint in inspector.get_foreign_keys(expected.name)
        }
        assert expected_foreign_keys == actual_foreign_keys
        expected_checks = {
            constraint.name
            for constraint in expected.constraints
            if isinstance(constraint, CheckConstraint)
        }
        actual_checks = {
            constraint["name"]
            for constraint in inspector.get_check_constraints(expected.name)
        }
        assert expected_checks <= actual_checks
    with engine.connect() as connection:
        policy = connection.execute(
            text(
                "SELECT policy_id, revision, definition_digest "
                "FROM observation_freshness_policies"
            )
        ).mappings().one()
        limit_set = connection.execute(
            text(
                "SELECT limit_set_id, item_id, catalog_digest, limit_revision "
                "FROM telemetry_limit_sets"
            )
        ).mappings().one()
    assert dict(policy) == {
        "policy_id": "simulator-default",
        "revision": "v07-r1",
        "definition_digest": (
            "43799d5f5fd3e4f5744e4de5b302c10fe27d3601130ba14c0ee31bd62712702e"
        ),
    }
    assert dict(limit_set) == {
        "limit_set_id": "LIMIT.TM.POWER.BUS_VOLTAGE",
        "item_id": "TM.POWER.BUS_VOLTAGE",
        "catalog_digest": v0005_observation_projection.DEFAULT_CATALOG_DIGEST,
        "limit_revision": "v07-r1",
    }


def seed_populated_v02_schema(engine) -> None:
    legacy_metadata = MetaData()
    for table_name in V03_TABLES:
        Base.metadata.tables[table_name].to_metadata(legacy_metadata)
    legacy_metadata.create_all(engine)
    with engine.begin() as connection:
        connection.exec_driver_sql(
            "INSERT INTO executions "
            "(id, procedure_id, procedure_name, procedure_hash, procedure_source, steps, "
            "ir_version, variables, context_id, created_by, creation_idempotency_key, "
            "state, revision, current_step, total_steps, worker_generation, next_sequence, "
            "created_at, updated_at) VALUES "
            "('legacy-id', 'legacy-procedure', 'Legacy Procedure', "
            "'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', "
            "'Log(''legacy'')', '[{\"type\":\"log\"}]', '0.2', '{}', 'simulator', "
            "'legacy.operator', 'legacy-create', 'completed', 3, 1, 1, 1, 2, "
            "CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)"
        )
        connection.exec_driver_sql(
            "INSERT INTO events "
            "(id, execution_id, sequence, event_type, source, severity, payload, created_at) "
            "VALUES ('legacy-event', 'legacy-id', 1, 'step.log', 'supervisor', 'info', "
            "'{\"message\":\"legacy\"}', CURRENT_TIMESTAMP)"
        )
        connection.exec_driver_sql(
            "INSERT INTO commands "
            "(id, execution_id, command_type, status, idempotency_key, expected_revision, "
            "actor, role, reason, correlation_id, request_payload, result_payload, "
            "created_at, completed_at) VALUES "
            "('legacy-command', 'legacy-id', 'start', 'completed', 'legacy-start', 0, "
            "'legacy.operator', 'operator', 'legacy test', 'legacy-correlation', '{}', '{}', "
            "CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)"
        )
        connection.exec_driver_sql(
            "INSERT INTO prompts "
            "(id, execution_id, step_index, status, question, choices, default_choice, "
            "response, responded_by, created_at, responded_at) VALUES "
            "('legacy-prompt', 'legacy-id', 0, 'responded', 'Continue?', '[\"yes\"]', "
            "'yes', 'yes', 'legacy.operator', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)"
        )
        connection.exec_driver_sql("ALTER TABLE executions DROP COLUMN variables")
        connection.exec_driver_sql("ALTER TABLE executions DROP COLUMN ir_version")


def assert_v02_records_preserved(engine) -> None:
    with engine.connect() as connection:
        execution = connection.execute(
            text(
                "SELECT procedure_hash, ir_version, variables "
                "FROM executions WHERE id = 'legacy-id'"
            )
        ).one()
        assert execution.procedure_hash == "a" * 64
        assert execution.ir_version == "0.2"
        variables = execution.variables
        normalized_variables = json.loads(variables) if isinstance(variables, str) else variables
        assert normalized_variables == {}
        assert connection.scalar(text("SELECT COUNT(*) FROM events WHERE id='legacy-event'")) == 1
        assert connection.scalar(
            text("SELECT COUNT(*) FROM commands WHERE id='legacy-command'")
        ) == 1
        assert connection.scalar(
            text("SELECT COUNT(*) FROM prompts WHERE id='legacy-prompt'")
        ) == 1


def seed_populated_v03_schema(engine) -> None:
    """Construct the accepted v0.3 schema without consulting the live ORM."""

    applied_at = datetime(2026, 7, 19, 12, 0, tzinfo=timezone.utc)
    with engine.begin() as connection:
        schema_migrations.create(connection, checkfirst=True)
        v0001_initial.upgrade(connection)
        connection.execute(
            schema_migrations.insert().values(
                version=v0001_initial.VERSION,
                applied_at=applied_at,
            )
        )
        v0002_execution_variables.upgrade(connection)
        connection.execute(
            schema_migrations.insert().values(
                version=v0002_execution_variables.VERSION,
                applied_at=applied_at,
            )
        )
        accepted_v03_executions = Table(
            "executions", MetaData(), autoload_with=connection
        )
        connection.execute(
            accepted_v03_executions.insert().values(
                id="v03-execution",
                procedure_id="accepted-v03-procedure",
                procedure_name="Accepted v0.3 Procedure",
                procedure_hash="3" * 64,
                procedure_source='Telemetry("SIM.TEMP")\nPrompt("Continue?")',
                steps=[
                    {"type": "telemetry", "channel": "SIM.TEMP"},
                    {"type": "prompt", "question": "Continue?"},
                ],
                context_id="simulator",
                created_by="v03.operator",
                creation_idempotency_key="v03-create-key",
                state="recovery_required",
                revision=7,
                current_step=1,
                total_steps=2,
                worker_generation=3,
                next_sequence=8,
                created_at=applied_at,
                updated_at=applied_at,
                ir_version="0.3",
                variables={"counter": 7, "enabled": True, "label": "checkpoint"},
            )
        )
        event_types = (
            "procedure.loaded",
            "execution.created",
            "telemetry.sampled",
            "prompt.opened",
            "execution.checkpointed",
            "audit.recorded",
            "recovery.required",
        )
        for sequence, event_type in enumerate(event_types, start=1):
            connection.execute(
                v0001_initial.events.insert().values(
                    id=f"v03-event-{sequence}",
                    execution_id="v03-execution",
                    sequence=sequence,
                    event_type=event_type,
                    source="supervisor",
                    severity="info",
                    correlation_id="00000000-0000-0000-0000-000000000901",
                    causation_id="00000000-0000-0000-0000-000000000902",
                    payload={
                        "sequence": sequence,
                        "checkpoint": {"counter": 7},
                        "report_fragment": event_type == "audit.recorded",
                    },
                    created_at=applied_at,
                )
            )
        connection.execute(
            v0001_initial.commands.insert().values(
                id="v03-command",
                execution_id="v03-execution",
                command_type="recover",
                status="completed",
                idempotency_key="v03-recover-key",
                expected_revision=6,
                actor="v03.operator",
                role="operator",
                reason="recover accepted v0.3 checkpoint",
                correlation_id="00000000-0000-0000-0000-000000000903",
                request_payload={"expected_revision": 6},
                result_payload={"state": "recovery_required"},
                created_at=applied_at,
                completed_at=applied_at,
            )
        )
        connection.execute(
            v0001_initial.prompts.insert().values(
                id="v03-prompt",
                execution_id="v03-execution",
                step_index=1,
                status="responded",
                question="Continue?",
                choices=["yes", "no"],
                default_choice="yes",
                response="yes",
                responded_by="v03.operator",
                created_at=applied_at,
                responded_at=applied_at,
            )
        )


def canonical_v03_snapshot(engine) -> dict[str, list[dict[str, object]]]:
    snapshot: dict[str, list[dict[str, object]]] = {}
    with engine.connect() as connection:
        for table_name in V03_TABLES:
            table = Table(table_name, MetaData(), autoload_with=connection)
            ordering = tuple(table.primary_key.columns)
            rows = connection.execute(table.select().order_by(*ordering)).mappings()
            snapshot[table_name] = [dict(row) for row in rows]
    return snapshot


def migrate_to_v0007_predecessor(engine, monkeypatch) -> None:
    v0007_index = next(
        index
        for index, migration in enumerate(migration_runner.MIGRATIONS)
        if migration.VERSION == v0007_data_local_service.VERSION
    )
    with monkeypatch.context() as migration_scope:
        migration_scope.setattr(
            migration_runner,
            "MIGRATIONS",
            migration_runner.MIGRATIONS[:v0007_index],
        )
        assert migration_runner.run_migrations(engine) == tuple(
            migration.VERSION for migration in migration_runner.MIGRATIONS
        )
    assert database_version(engine) == "0006_observation_conditions"


def assert_v0007_remains_pending(engine) -> None:
    assert database_version(engine) == "0006_observation_conditions"
    assert not set(DATA_TABLES).intersection(inspect(engine).get_table_names())


def assert_populated_v03_upgrade_preserves_every_record(engine) -> None:
    seed_populated_v03_schema(engine)
    before = canonical_v03_snapshot(engine)

    assert run_migrations(engine) == (
        "0003_driver_foundation",
        "0004_operator_workspace",
        "0005_observation_projection",
        "0006_observation_conditions",
        "0007_data_local_service",
        "0008_development_environment",
        "0009_procedure_catalog_availability",
        "0010_shadow_pilot",
        "0011_dss_language_ledger",
        "0012_dss_epoch_index",
        "0013_observation_outbox_index",
    )
    assert canonical_v03_snapshot(engine) == before
    assert database_version(engine) == "0013_observation_outbox_index"
    assert_driver_schema_contract(engine)
    assert_operator_schema_contract(engine)
    assert_observation_schema_contract(engine)
    with engine.connect() as connection:
        assert connection.scalar(
            text("SELECT COUNT(*) FROM driver_profiles WHERE enabled")
        ) == 0
        for table_name in DRIVER_TABLES:
            if table_name == "driver_profiles":
                continue
            assert connection.scalar(text(f"SELECT COUNT(*) FROM {table_name}")) == 0


def test_migrations_create_fresh_schema_and_are_idempotent(tmp_path) -> None:
    engine = create_engine(f"sqlite:///{(tmp_path / 'fresh.db').as_posix()}")

    assert run_migrations(engine) == (
        "0001_initial",
        "0002_execution_variables",
        "0003_driver_foundation",
        "0004_operator_workspace",
        "0005_observation_projection",
        "0006_observation_conditions",
        "0007_data_local_service",
        "0008_development_environment",
        "0009_procedure_catalog_availability",
        "0010_shadow_pilot",
        "0011_dss_language_ledger",
        "0012_dss_epoch_index",
        "0013_observation_outbox_index",
    )
    assert run_migrations(engine) == ()
    assert database_version(engine) == "0013_observation_outbox_index"
    tables = set(inspect(engine).get_table_names())
    assert {"schema_migrations", "executions", "events", "commands", "prompts"} <= tables
    assert {
        "driver_profiles",
        "driver_host_generations",
        "driver_capabilities",
        "driver_contexts",
        "driver_context_generations",
        "driver_bindings",
        "driver_operations",
        "driver_operation_attempts",
        "driver_operation_transitions",
        "driver_audit_events",
        "driver_outbox",
    } <= tables
    assert_driver_schema_contract(engine)
    assert_operator_schema_contract(engine)
    assert_observation_schema_contract(engine)


def test_v0007_preflight_requires_safe_backup_directory_before_ddl(
    tmp_path: Path, monkeypatch
) -> None:
    engine = create_engine(f"sqlite:///{(tmp_path / 'preflight.sqlite').as_posix()}")
    migrate_to_v0007_predecessor(engine, monkeypatch)

    with pytest.raises(RuntimeError, match="explicit backup directory"):
        migration_runner.run_migrations(engine)
    assert_v0007_remains_pending(engine)

    with pytest.raises(RuntimeError, match="existing, safely writable non-link"):
        migration_runner.run_migrations(
            engine,
            v0007_backup_directory=tmp_path / "missing-backup-directory",
        )
    assert_v0007_remains_pending(engine)

    regular_file = tmp_path / "not-a-directory"
    regular_file.write_bytes(b"not a migration backup directory")
    with pytest.raises(RuntimeError, match="existing, safely writable non-link"):
        migration_runner.run_migrations(
            engine,
            v0007_backup_directory=regular_file,
        )
    assert_v0007_remains_pending(engine)

    backup_directory = tmp_path / "migration-backups"
    backup_directory.mkdir()
    link = tmp_path / "migration-backup-link"
    try:
        link.symlink_to(backup_directory, target_is_directory=True)
    except OSError:
        pass
    else:
        with pytest.raises(RuntimeError, match="existing, safely writable non-link"):
            migration_runner.run_migrations(
                engine,
                v0007_backup_directory=link,
            )
        assert_v0007_remains_pending(engine)

    assert migration_runner.run_migrations(
        engine,
        v0007_backup_directory=backup_directory,
    ) == (
        "0007_data_local_service",
        "0008_development_environment",
        "0009_procedure_catalog_availability",
        "0010_shadow_pilot",
        "0011_dss_language_ledger",
        "0012_dss_epoch_index",
        "0013_observation_outbox_index",
    )
    assert list(backup_directory.iterdir()) == []


def test_v0007_preflight_rejects_unknown_table_before_ddl(
    tmp_path: Path, monkeypatch
) -> None:
    engine = create_engine(f"sqlite:///{(tmp_path / 'unknown.sqlite').as_posix()}")
    migrate_to_v0007_predecessor(engine, monkeypatch)
    backup_directory = tmp_path / "unknown-backups"
    backup_directory.mkdir()
    with engine.begin() as connection:
        connection.exec_driver_sql("CREATE TABLE arbitrary_unknown_object (id INTEGER)")

    with pytest.raises(RuntimeError, match="object inventory differs"):
        migration_runner.run_migrations(
            engine,
            v0007_backup_directory=backup_directory,
        )
    assert_v0007_remains_pending(engine)


def test_v0007_preflight_rejects_fingerprint_drift_before_ddl(
    tmp_path: Path, monkeypatch
) -> None:
    engine = create_engine(f"sqlite:///{(tmp_path / 'drifted.sqlite').as_posix()}")
    migrate_to_v0007_predecessor(engine, monkeypatch)
    backup_directory = tmp_path / "drifted-backups"
    backup_directory.mkdir()
    with engine.begin() as connection:
        connection.exec_driver_sql(
            "ALTER TABLE executions ADD COLUMN arbitrary_drift INTEGER"
        )

    with pytest.raises(RuntimeError, match="schema fingerprint differs"):
        migration_runner.run_migrations(
            engine,
            v0007_backup_directory=backup_directory,
        )
    assert_v0007_remains_pending(engine)


def test_v0007_sqlite_hard_exit_rolls_back_first_ddl(
    tmp_path: Path, monkeypatch
) -> None:
    database_path = tmp_path / "hard-exit.sqlite"
    engine = create_engine(f"sqlite:///{database_path.as_posix()}")
    migrate_to_v0007_predecessor(engine, monkeypatch)
    engine.dispose()
    backup_directory = tmp_path / "hard-exit-backups"
    backup_directory.mkdir()

    process = multiprocessing.get_context("spawn").Process(
        target=crash_after_first_v0007_sqlite_ddl,
        args=(str(database_path), str(backup_directory)),
    )
    process.start()
    process.join(timeout=30)
    if process.is_alive():
        process.kill()
        process.join(timeout=5)
        pytest.fail("v0007 hard-exit subprocess did not terminate")
    assert process.exitcode == V0007_CRASH_EXIT_CODE

    reopened = create_engine(f"sqlite:///{database_path.as_posix()}")
    try:
        assert_v0007_remains_pending(reopened)
        with reopened.connect() as connection:
            assert connection.scalar(
                text(
                    "SELECT COUNT(*) FROM schema_migrations "
                    "WHERE version = '0007_data_local_service'"
                )
            ) == 0
        assert migration_runner.run_migrations(
            reopened,
            v0007_backup_directory=backup_directory,
        ) == (
            "0007_data_local_service",
            "0008_development_environment",
            "0009_procedure_catalog_availability",
            "0010_shadow_pilot",
            "0011_dss_language_ledger",
            "0012_dss_epoch_index",
            "0013_observation_outbox_index",
        )
    finally:
        reopened.dispose()


def test_migrations_upgrade_populated_v02_sqlite_database(tmp_path) -> None:
    engine = create_engine(f"sqlite:///{(tmp_path / 'legacy.db').as_posix()}")
    seed_populated_v02_schema(engine)

    run_migrations(engine)

    columns = {column["name"] for column in inspect(engine).get_columns("executions")}
    assert {"variables", "ir_version"} <= columns
    assert_v02_records_preserved(engine)
    assert_operator_schema_contract(engine)


def test_migrations_upgrade_populated_v03_sqlite_database_without_record_drift(
    tmp_path,
) -> None:
    engine = create_engine(f"sqlite:///{(tmp_path / 'accepted-v03.db').as_posix()}")
    assert_populated_v03_upgrade_preserves_every_record(engine)


def test_failed_migration_rolls_back_and_remains_pending(tmp_path, monkeypatch) -> None:
    engine = create_engine(f"sqlite:///{(tmp_path / 'rollback.db').as_posix()}")
    run_migrations(engine)

    def fail_after_write(connection) -> None:
        connection.execute(
            text(
                "INSERT INTO schema_migrations (version, applied_at) "
                "VALUES ('9998_transient_write', CURRENT_TIMESTAMP)"
            )
        )
        raise RuntimeError("controlled migration failure")

    failing = SimpleNamespace(VERSION="9999_controlled_failure", upgrade=fail_after_write)
    monkeypatch.setattr(
        migration_runner,
        "MIGRATIONS",
        (*migration_runner.MIGRATIONS, failing),
    )

    with pytest.raises(RuntimeError, match="controlled migration failure"):
        run_migrations(engine)

    with engine.connect() as connection:
        assert connection.scalar(
            text(
                "SELECT COUNT(*) FROM schema_migrations "
                "WHERE version IN ('9998_transient_write', '9999_controlled_failure')"
            )
        ) == 0


@pytest.mark.parametrize(
    ("stored_versions", "expected_error"),
    [
        (("9999_future",), "unsupported migration versions"),
        (("0002_execution_variables",), "history is not a valid prefix"),
    ],
)
def test_migrations_reject_unknown_or_gapped_history(
    tmp_path, stored_versions: tuple[str, ...], expected_error: str
) -> None:
    engine = create_engine(f"sqlite:///{(tmp_path / 'invalid-history.db').as_posix()}")
    run_migrations(engine)
    with engine.begin() as connection:
        connection.exec_driver_sql("DELETE FROM schema_migrations")
        for version in stored_versions:
            connection.execute(
                text(
                    "INSERT INTO schema_migrations (version, applied_at) "
                    "VALUES (:version, CURRENT_TIMESTAMP)"
                ),
                {"version": version},
            )

    with pytest.raises(RuntimeError, match=expected_error):
        run_migrations(engine)


def postgresql_migration_engine():
    database_url = os.environ["SPELL_MIGRATION_TEST_DATABASE_URL"]
    assert make_url(database_url).database == "spell_migration_test"
    return create_engine(database_url)


@pytest.mark.skipif(
    not os.getenv("SPELL_MIGRATION_TEST_DATABASE_URL"),
    reason="dedicated PostgreSQL migration database not configured",
)
def test_migrations_create_fresh_postgresql_schema_and_are_idempotent() -> None:
    engine = postgresql_migration_engine()
    reset_migration_database(engine)

    with engine.begin() as connection:
        connection.exec_driver_sql("CREATE TABLE reset_guard_sentinel (id INTEGER)")
    configured_url = engine.url
    engine.url = configured_url.set(database="spell_test")
    try:
        with pytest.raises(
            RuntimeError,
            match="PostgreSQL test reset requires the exact dedicated test database",
        ):
            reset_migration_database(engine)
    finally:
        engine.url = configured_url
    assert "reset_guard_sentinel" in inspect(engine).get_table_names(schema="public")

    blocker = engine.connect()
    blocker_transaction = blocker.begin()
    blocker.exec_driver_sql("LOCK TABLE reset_guard_sentinel IN ACCESS SHARE MODE")
    blocker_pid = blocker.scalar(text("SELECT pg_backend_pid()"))
    assert blocker_transaction.is_active
    try:
        reset_migration_database(engine)
    finally:
        blocker.invalidate()
        blocker.close()
    with engine.connect() as connection:
        assert connection.scalar(
            text("SELECT COUNT(*) FROM pg_stat_activity WHERE pid = :pid"),
            {"pid": blocker_pid},
        ) == 0

    assert run_migrations(engine) == (
        "0001_initial",
        "0002_execution_variables",
        "0003_driver_foundation",
        "0004_operator_workspace",
        "0005_observation_projection",
        "0006_observation_conditions",
        "0007_data_local_service",
        "0008_development_environment",
        "0009_procedure_catalog_availability",
        "0010_shadow_pilot",
        "0011_dss_language_ledger",
        "0012_dss_epoch_index",
        "0013_observation_outbox_index",
    )
    assert run_migrations(engine) == ()
    assert database_version(engine) == "0013_observation_outbox_index"
    assert_driver_schema_contract(engine)
    assert_operator_schema_contract(engine)
    assert_observation_schema_contract(engine)

    reset_migration_database(engine)
    assert inspect(engine).get_table_names(schema="public") == []
    assert run_migrations(engine) == (
        "0001_initial",
        "0002_execution_variables",
        "0003_driver_foundation",
        "0004_operator_workspace",
        "0005_observation_projection",
        "0006_observation_conditions",
        "0007_data_local_service",
        "0008_development_environment",
        "0009_procedure_catalog_availability",
        "0010_shadow_pilot",
        "0011_dss_language_ledger",
        "0012_dss_epoch_index",
        "0013_observation_outbox_index",
    )
    assert database_version(engine) == "0013_observation_outbox_index"


@pytest.mark.skipif(
    not os.getenv("SPELL_MIGRATION_TEST_DATABASE_URL"),
    reason="dedicated PostgreSQL migration database not configured",
)
def test_migrations_upgrade_populated_v02_postgresql_database() -> None:
    engine = postgresql_migration_engine()
    reset_migration_database(engine)
    seed_populated_v02_schema(engine)

    run_migrations(engine)

    columns = {column["name"] for column in inspect(engine).get_columns("executions")}
    assert {"variables", "ir_version"} <= columns
    assert_v02_records_preserved(engine)
    assert_driver_schema_contract(engine)
    assert_operator_schema_contract(engine)


@pytest.mark.skipif(
    not os.getenv("SPELL_MIGRATION_TEST_DATABASE_URL"),
    reason="dedicated PostgreSQL migration database not configured",
)
def test_migrations_upgrade_populated_v03_postgresql_database_without_record_drift() -> None:
    engine = postgresql_migration_engine()
    reset_migration_database(engine)
    assert_populated_v03_upgrade_preserves_every_record(engine)


def assert_v0011_upgrade_preserves_predecessor_and_ledger(engine, monkeypatch) -> None:
    seed_populated_v03_schema(engine)
    before = canonical_v03_snapshot(engine)
    with monkeypatch.context() as scope:
        scope.setattr(migration_runner, "MIGRATIONS", tuple(row for row in migration_runner.MIGRATIONS if row.VERSION < "0011"))
        run_migrations(engine)
    assert database_version(engine) == "0010_shadow_pilot"
    assert "dss_language_cases" not in inspect(engine).get_table_names()
    assert canonical_v03_snapshot(engine) == before
    with monkeypatch.context() as scope:
        scope.setattr(migration_runner, "MIGRATIONS", tuple(row for row in migration_runner.MIGRATIONS if row.VERSION < "0012"))
        assert run_migrations(engine) == ("0011_dss_language_ledger",)
    assert database_version(engine) == "0011_dss_language_ledger"
    assert run_migrations(engine) == ("0012_dss_epoch_index", "0013_observation_outbox_index")
    assert canonical_v03_snapshot(engine) == before
    ledger = v0011_dss_language_ledger.language_cases
    created_at = datetime(2026, 10, 3, tzinfo=timezone.utc)
    with engine.begin() as connection:
        connection.execute(ledger.insert(), [
            {"request_id": "00000000-0000-0000-0000-000000000001", "subject": "case-pending",
             "execution_id": "v03-execution", "request_hash": "a" * 64,
             "request": {"source_sha256": "b" * 64, "selection": 1}, "binding_hash": "c" * 64,
             "state": "DISPATCHING", "result": None, "result_hash": None,
             "created_at": created_at, "settled_at": None},
            {"request_id": "00000000-0000-0000-0000-000000000002", "subject": "case-settled",
             "execution_id": "v03-execution", "request_hash": "d" * 64,
             "request": {"source_sha256": "e" * 64, "selection": 2}, "binding_hash": "f" * 64,
             "state": "SETTLED", "result": {"outcome": "PASS", "packets": ["1" * 64]},
             "result_hash": "2" * 64, "created_at": created_at, "settled_at": created_at},
        ])
        expected = [dict(row) for row in connection.execute(ledger.select().order_by(ledger.c.subject)).mappings()]
    engine.dispose()
    assert run_migrations(engine) == ()
    with engine.connect() as connection:
        v0011_dss_language_ledger.verify(connection)
        assert [dict(row) for row in connection.execute(ledger.select().order_by(ledger.c.subject)).mappings()] == expected
    assert canonical_v03_snapshot(engine) == before
    reset_test_database(engine)
    assert inspect(engine).get_table_names() == []
    assert run_migrations(engine)[-1] == "0013_observation_outbox_index"


def test_v0011_sqlite_upgrade_preserves_prior_data_and_repeated_durable_ledger(tmp_path, monkeypatch):
    engine = create_engine(f"sqlite:///{(tmp_path / 'v0011-upgrade.db').as_posix()}")
    try:
        assert_v0011_upgrade_preserves_predecessor_and_ledger(engine, monkeypatch)
    finally:
        engine.dispose()


@pytest.mark.skipif(not os.getenv("SPELL_MIGRATION_TEST_DATABASE_URL"),
                   reason="dedicated PostgreSQL migration database not configured")
def test_v0011_postgresql_upgrade_preserves_prior_data_and_repeated_durable_ledger(monkeypatch):
    engine = postgresql_migration_engine()
    reset_test_database(engine)
    try:
        assert_v0011_upgrade_preserves_predecessor_and_ledger(engine, monkeypatch)
    finally:
        reset_test_database(engine)
        run_migrations(engine)
        engine.dispose()


def test_v0011_repeated_migration_rejects_ledger_schema_drift(tmp_path):
    engine = create_engine(f"sqlite:///{(tmp_path / 'v0011-drift.db').as_posix()}")
    try:
        run_migrations(engine)
        with engine.begin() as connection:
            connection.exec_driver_sql("ALTER TABLE dss_language_cases ADD COLUMN unreviewed INTEGER")
        with pytest.raises(RuntimeError, match="ledger schema differs"):
            run_migrations(engine)
    finally:
        engine.dispose()


@pytest.mark.skipif(
    not os.getenv("SPELL_MIGRATION_TEST_DATABASE_URL"),
    reason="dedicated PostgreSQL migration database not configured",
)
def test_failed_postgresql_migration_rolls_back_and_remains_pending(
    monkeypatch,
) -> None:
    engine = postgresql_migration_engine()
    reset_migration_database(engine)
    run_migrations(engine)

    def fail_after_write(connection) -> None:
        connection.execute(
            text(
                "INSERT INTO schema_migrations (version, applied_at) "
                "VALUES ('9998_transient_write', CURRENT_TIMESTAMP)"
            )
        )
        connection.execute(
            text(
                "UPDATE driver_profiles SET enabled = TRUE "
                "WHERE id = 'local-synthetic-simulator'"
            )
        )
        raise RuntimeError("controlled PostgreSQL migration failure")

    failing = SimpleNamespace(VERSION="9999_controlled_failure", upgrade=fail_after_write)
    monkeypatch.setattr(
        migration_runner,
        "MIGRATIONS",
        (*migration_runner.MIGRATIONS, failing),
    )

    with pytest.raises(RuntimeError, match="controlled PostgreSQL migration failure"):
        run_migrations(engine)

    with engine.connect() as connection:
        assert connection.scalar(
            text(
                "SELECT COUNT(*) FROM schema_migrations "
                "WHERE version IN ('9998_transient_write', '9999_controlled_failure')"
            )
        ) == 0
        assert connection.scalar(
            text(
                "SELECT enabled FROM driver_profiles "
                "WHERE id = 'local-synthetic-simulator'"
            )
        ) is False


@pytest.mark.skipif(
    not os.getenv("SPELL_MIGRATION_TEST_DATABASE_URL"),
    reason="dedicated PostgreSQL migration database not configured",
)
def test_v0007_postgresql_preflight_fails_closed_before_ddl(
    tmp_path: Path, monkeypatch
) -> None:
    engine = postgresql_migration_engine()
    reset_migration_database(engine)
    try:
        migrate_to_v0007_predecessor(engine, monkeypatch)

        with pytest.raises(RuntimeError, match="explicit backup directory"):
            migration_runner.run_migrations(engine)
        assert_v0007_remains_pending(engine)

        regular_file = tmp_path / "postgresql-not-a-directory"
        regular_file.write_bytes(b"not a migration backup directory")
        with pytest.raises(RuntimeError, match="existing, safely writable non-link"):
            migration_runner.run_migrations(
                engine,
                v0007_backup_directory=regular_file,
            )
        assert_v0007_remains_pending(engine)

        backup_directory = tmp_path / "postgresql-migration-backups"
        backup_directory.mkdir()
        with engine.begin() as connection:
            connection.exec_driver_sql(
                "CREATE TABLE arbitrary_unknown_object (id INTEGER)"
            )
        with pytest.raises(RuntimeError, match="object inventory differs"):
            migration_runner.run_migrations(
                engine,
                v0007_backup_directory=backup_directory,
            )
        assert_v0007_remains_pending(engine)

        with engine.begin() as connection:
            connection.exec_driver_sql("DROP TABLE arbitrary_unknown_object")
            connection.exec_driver_sql(
                "ALTER TABLE executions ADD COLUMN arbitrary_drift INTEGER"
            )
        with pytest.raises(RuntimeError, match="schema fingerprint differs"):
            migration_runner.run_migrations(
                engine,
                v0007_backup_directory=backup_directory,
            )
        assert_v0007_remains_pending(engine)
        assert list(backup_directory.iterdir()) == []
    finally:
        reset_migration_database(engine)
        run_migrations(engine)
        engine.dispose()
